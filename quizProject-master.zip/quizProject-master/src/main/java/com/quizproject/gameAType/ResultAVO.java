package com.quizproject.gameAType;

import lombok.Data;

@Data
public class ResultAVO {
    private int gId;
    private String value1;
    private String value2;
//    private String value3;
}
