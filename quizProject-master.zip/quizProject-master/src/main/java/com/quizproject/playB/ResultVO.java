package com.quizproject.playB;

import lombok.Data;

@Data
public class ResultVO {
    private int good;
    private int bad;
    private int total;
}
