package com.quizproject.playB;

import lombok.Data;

@Data
public class PlayVO {
    private int pId;
    private String state;
    private int gId;
    private int uId;
    private String firstDt;
    private String lastDt;
}
