package com.quizproject.playB;

import lombok.Data;

@Data
public class PlayItemVO {
    private int piId;
    private String answer;
    private int pId;
    private int giId;
    private int serial;
    private String firstDt;
    private String lastDt;
}
