package com.quizproject.playAType;

import lombok.Data;

@Data
public class PlayAVO {
    private int pId;
    private String state;
    private int gId;
    private int uId;
}
