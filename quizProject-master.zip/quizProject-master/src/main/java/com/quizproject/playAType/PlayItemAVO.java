package com.quizproject.playAType;

import lombok.Data;

@Data
public class PlayItemAVO {
    private int piId;
    private String answer1;
    private String answer2;
    private String answer3;
    private int pId;
    private int giId1;
    private int giId2;
    private int giId3;
    private int serial;
}
